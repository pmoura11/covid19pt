# onesaitplatform-webproject-template
This repository contains a complete template in order to create your webproject integrated with plafform login and dashboards in a simple way

##How yo use
All configuration options on: assets/app/js/aplication-config.js

In application config you can configure:
- Application path
- Application Access: PUBLIC (splash) or PRIVATE (login oauth)
- Login
- Application Index
	> logo
	> headers
	> menu
	> initial content (dashboards from console)
	> footer

- Application Styles

Find details in our Developer Portal: http://bit.ly/2LJOUOC