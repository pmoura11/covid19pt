All configuration options on: assets/app/js/aplication-config.js

In application config you can configure:
> Application path
> Application Access: PUBLIC (splash) or PRIVATE (login oauth)
> Login
> Application Index
	> logo
	> headers
	> menu
	> initial content (dashboards from console)
	> footer

> Application Styles

> Version v.1:
	> saving configuration via API to frontendConfiguration Ontology and allow each user to get his own frontend configuration
